#coding:	cp932
import sys
import os

args = sys.argv
DIR_PATH	=	args[1]

def MKDIR(INPUT_PATH):
    pass
    if os.path.isdir(INPUT_PATH) != True:
    	os.mkdir(INPUT_PATH)

if __name__=="__MKDIR__":
    main(DIR_PATH)
