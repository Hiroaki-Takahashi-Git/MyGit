import sys

args = sys.argv
IN_NUMBER = args[1]

def main(str_num):
    pass
    return(int(str_num))

if __name__=="__main__":
    ret = main(IN_NUMBER)
    print(ret)
